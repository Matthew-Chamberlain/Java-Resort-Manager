import java.util.*;
/**
 * This class implements the user interface and display output and allows input from the user.
 * 
 * @author Matthew Chamberlain
 * @version 09/04/20
 */
public class ResortUI
{
    
    private Scanner reader = new Scanner(System.in);
    private ResortManager wayward = new ResortManager("Wayward Asteroids Resort"); 
    
    /** This method is used to call the right method by depending on a number given by the user in the getOption method
     *  A loop is used to keep displaying the menu until the user chooses the quit option
     * 
     */
    public void runUI()
    {   

        int choice = getOption();        
        while (choice != 0)
        {            
            // process choice
            if      (choice == 1){listAllWorlds();}
            else if (choice == 2){listAllCardsbyWorld();}
            else if (choice == 3){listOneWorld();}
            else if (choice == 4){findACard();}
            else if (choice == 5){tryTravel();}
            else if (choice == 6){travelNow();}
            else if (choice == 7){updateCredits();}
            else if (choice == 8){goHome();}
            else if (choice == 9){convertPts();}
            else if (choice == 10){evacuate();}
                // output menu & get choice
            choice = getOption();
        }
        System.out.println("\nThank-you");
    }
    
    /** This method prints out the menu to the user and also reads in input from the user
     *  @return the number of the option that the user has chosen.
     */
    private int getOption()
    {
       System.out.println("What would you like to do ?");
       System.out.println("0. Quit");
       System.out.println("1. List all world details");
       System.out.println("2. List all cards on each worlds");
       System.out.println("3. List all cards on one world");
       System.out.println("4. Find a card");
       System.out.println("5. Say if card can move by shuttle");
       System.out.println("6. Move a card by shuttle");
       System.out.println("7. Top up credits");
       System.out.println("8. Move a card to home world");
       System.out.println("9. Convert points to credits");
       System.out.println("10. Evacuate all");

       System.out.println("Enter your choice");
       // read choice
       int option = reader.nextInt();
       reader.nextLine();
       return option;
    }
    
    // This one has been done for you 
    /**This method prints out a string representation of all the worlds and all the cards on those worlds.
     * 
     */
    private void listAllWorlds()
    {
        System.out.println(wayward.toString());
    }
    
    // provide the code here  
    /** This method lists only the cards that are on each world
     * 
     */
    private void listAllCardsbyWorld()
    {
        System.out.println(wayward.getAllCardsOnEachWorld());
    }
   
    // This one has been done for you
    /**This method lists the cards on a specific world which is dependant on input of the user.
     * 
     */
    private void listOneWorld()
    {
        System.out.println("Enter name of world");
        String ww = reader.nextLine();
        System.out.println(wayward.getAllCardsOnWorld(ww));
    }
    
    // provide the code here
    /** This method prints the world name of that a specified card is on.
     * 
     */
    private void findACard()
    {
       System.out.println("Enter a card ID");
       int cr = reader.nextInt();
       reader.nextLine();
       System.out.println(wayward.findCard(cr));
    }
    
    // This one has been done for you 
    /** This method prints out a true or false if travel for a specified card on a specified shuttle is possible or not.
     * 
     */
    private void tryTravel()
    {
        System.out.println("Enter card id");
        int trav = reader.nextInt();
        reader.nextLine();
        System.out.println("Enter shuttle code");
        String shuttle = reader.nextLine();
        System.out.println(wayward.canTravel(trav,shuttle));
    }
    
    // provide the code here
    /** This method prints out a message stating whether a given cards attempt to travel on a given shuttle is successful or not.
     * 
     */
    private void travelNow()
    {
        System.out.println("Enter card id");
        int trav = reader.nextInt();
        reader.nextLine();
        System.out.println("Enter shuttle code");
        String shuttle = reader.nextLine();
        System.out.println(wayward.travel(trav, shuttle));
    }
    
    // provide the code here if you have done Task 7
    /** This method is used to adds credits to a card. The card id and the amount of credits are supplied by the user.
     * 
     */
    private void updateCredits()
    {
        System.out.println("Enter card id");
        int id = reader.nextInt();
        reader.nextLine();
        System.out.println("Enter amount of credits");
        int credits = reader.nextInt();
        reader.nextLine();
        wayward.topUpCredits(id, credits);
    }
    
    // provide the code here
    /** This method moves the card specified by the card id given by the user back to the home world without changing credits or loyalty points
     * 
     */
    private void goHome()
    {
        System.out.println("Enter card id");
        int id = reader.nextInt();
        reader.nextLine();
        wayward.moveHome(id);
    }
    
    // provide the code here
    /** This method converts the loyalty points of a card into credits. 
     * 
     */
    private void convertPts()
    {
        System.out.println("Enter card id");
        int id = reader.nextInt();
        reader.nextLine();
        wayward.convertPoints(id);
    }
    
    // provide the code here
    /** This method moves all cards back to the home world without chaging credits or loyalty points
     * 
     */
    private void evacuate()
    {
        wayward.evacuateAll();
    }
    
    
}
