
/**
 * Used to test the program by creating a resort manager object and giving specific values to the methods.
 * 
 * @author Matthew Chamberlain 
 * @version 09/04/20
 */
public class MyTester 
{   
    ResortManager tester = new ResortManager("Wayward Asteroids Resort");
    /** Calls methods from the resource manager to test the system works correctly
     * 
     */
    public void doTest1()
    {   // write your  tests here
        System.out.println(tester.toString()); // tests the toString method works and tests that all cards are added to the home world when the application starts with the correct values.
        
        System.out.println(tester.canTravel(1000, "ABC1")); // tests the can travel method to check whether it will return true if the user enters a valid card id and a shuttle code 
        //for the world they are on
        System.out.println(tester.canTravel(1000, "CDE3"));// tests the can travel method to check whether it will return false if the user enters a valid card id and a valid shutttle code 
        //for a world that they are not on
        System.out.println(tester.canTravel(2000, "ABC1")); // tests the can travel method to check whether it will return false if the user enters a card id that does not exist 
        //and a valid shutttle code for a world that they are on
        System.out.println(tester.canTravel(1000, "zyx1")); // tests the can travel method to check whether it will return false if the user enters a valid card id 
        //and a shutttle code that does not exist
        
        System.out.println(tester.travel(1000, "ABC1")); 
        System.out.println(tester.getAllCardsOnWorld("Sprite"));
        System.out.println(tester.getAllCardsOnWorld("Home"));
        // tests the travel method to check wether it will allow a user to move if they enter a valid card id and a valid shuttle code 
        //for the world they area on. Also prints out the getAllCardsOnWorld method parsing the destination world to show if the card has been added to the destination worlds card collection 
        //and also to check if the credits, loyalty points have been changed correctly. Also prints out the getAllCardsOnWorld method parsing the source world to check wether the card is 
        //no longer on the source world
        
        System.out.println(tester.travel(1004, "ABC1"));
        System.out.println(tester.travel(1004, "CDE3"));
        System.out.println(tester.findCard(1004));
        // this tests tests wether a card will be denied travel on a shuttle if they do not have the credits required to do so. the first travel should be successful as Pan has 3 credits, 
        //however the second should fail as Pan will now have 0 credits. the findCard method is called to test that it works and to check that the card is not moved
        
        System.out.println(tester.getAllCardsOnWorld("Sprite"));
        tester.topUpCredits(1004, 10);
        System.out.println(tester.getAllCardsOnWorld("Sprite"));
        // this tests test the topUpCredits method by adding 10 credits to Pans card, who just ran out of credits, and then printing all the cards on the world Pan is on before and after to check 
        //they have increased
        
        System.out.println(tester.travel(1004, "GHJ6"));
        System.out.println(tester.travel(1000, "GHJ6")); 
        // this test is to check wether a card's travel will fail if the capacity of the world has been reached, despite both cards having the required rating and sufficient credits only 
        //the first tavel should be successful as the world solo only has a capcity of 1
        
        System.out.println(tester.travel(1004, "HJK7"));
        System.out.println(tester.getAllCardsOnWorld("Sprite"));
        tester.convertPoints(1004);
        System.out.println(tester.getAllCardsOnWorld("Sprite"));
        // this tests tests the convertPoints method works correctly, firstly Pan is moved back to sprite so that she has 6 loyalty points, then the cards on Sprite are printed to check her 
        //credits and points against after they are converted. Then the points are converted and the cards are printed again so that they can be compared. Pans credits should have gone up by 1 
        //and the loyalty points down by 4.
        
        System.out.println(tester.travel(1005, "ABC1"));
        System.out.println(tester.travel(1005, "CDE3"));
        System.out.println(tester.findCard(1005));
        // this tests tests wether a cards travel will be denied if they try to travel to a world which is higher rated than their cards rating the travel should be denied as Tropicana 
        //has a rating of 3 and quin's card has a rating of 1
        
        System.out.println(tester.getAllCardsOnEachWorld()); // this method is called to test the method which prints out all the cards on each world, which is option 2 of the UI. in addition 
        //it also is used to show wether all the cards are in the correct places as a result of the previous tests
        
        tester.moveHome(1000);
        System.out.println(tester.getAllCardsOnWorld("Home"));
        // this test is used to the moveHome method by moving Lynn back to the home world. All the cards on Home are printed after so they can be compared against the worlds on sprite from 
        //the previous test to show wether the card has moved and the credtis and points remain the same. 
        
        tester.evacuateAll();
        System.out.println(tester.getAllCardsOnEachWorld());
        // this tests tests the evacuateAll method and checks whether all the cards have been moved back to the home world by printing the cards on each world to check whether the 
        //home world has all the cards. This test can be compared against previous tests to show that none of the credits or points have been changed.
        
        System.out.println(tester.travel(1008, "ABC1"));
        System.out.println(tester.getAllCardsOnWorld("Sprite"));
        tester.topUpCredits(1008, -10);
        System.out.println(tester.getAllCardsOnWorld("Sprite"));
        // this tests tests that a user cannot top up their card with a negative amount of credits, the card has been moved to another world to make it easier to see the results of the test. 
        //The cards on the world are printed before and after so that the results can be compared
        
        System.out.println(tester.getAllCardsOnWorld("Sprite"));
        tester.convertPoints(1008);
        System.out.println(tester.getAllCardsOnWorld("Sprite"));
        // This tests is used to make sure a cards credits won't be converted if they are below 4.
    }
     
    
}
