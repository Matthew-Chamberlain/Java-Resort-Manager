
/**
 * Used to store information about shuttles including the shuttle code, the source world, and the destination world .
 *
 * @author Matthew Chamberlain
 * @version 09/04/20
 */
public class Shuttle
{
    private String journeyCode;
    private World sourceWorld;
    private World destinationWorld; 
    
    /** Creates a shuttle object storing the values given into the fields
     *  @param code represents the journey code of the shuttle
     *  @param source represents the world object that the shuttle is leaving
     *  @param destination represents the world object the shuttle is traveling to
     */    
    public Shuttle(String code, World source, World destination)
    {
        journeyCode = code;
        sourceWorld = source;
        destinationWorld = destination;
    }
    
    /** Returns the journey code of the shuttle
     *  @returns journey code
     */    
    public String getCode()
    {
        return journeyCode;
    }
    
    /** Returns the world object that the shuttle is leaving
     *  @returns source world
     */    
    public World getSourceWorld()
    {
        return sourceWorld;
    }
    
    /** Returns the world object that the shuttle is going to
     *  @returns destination world
     */    
    public World getDestinationWorld()
    {
        return destinationWorld;
    }
    
    /** Returns a true if a given card can travel on the shuttle and a false if it cannot
     *  A move can be made if:  
     *  the rating of the card  >= the rating of the destination world
     *  AND the destination world is not full
     *  AND the card has sufficient credits
     *  AND the card is currently in the source world
     *  AND the card id is for a card on the system
     *  AND the shuttle code is the code for a shuttle on the system
     *  @param card represents the card object that is checking whether it can travel on the shuttle
     *  @returns true if the card can travel on the shuttle and false if not
     */    
    public boolean canTravel(Card card)
    {
        if(card.getRating() >= destinationWorld.getRating() && card.getCredits() >= 3 && destinationWorld.isFull() == false && sourceWorld.isOnWorld(card.getID()))
        {
            return true;
        }
        else
        {
            return false;
        }
    }
    
    /** Takes 3 away from the amount of credits the card has and adds two to the cards lolyalty points. 
     *  Also removes the card from the array list of the source world and adds the card to the array list of the destination world
     *  Returns a string stating that travel has been successful
     *  @param card represents the card object that is travelling on the shuttle
     *  @return string stating that travel has been successful
     */
    public String travel(Card card)
    {
        card.changeCredits(-3);
        card.addPoints(2);
        sourceWorld.leave(card);
        destinationWorld.enter(card);
        return "\nTravel Successful";
    }
    
    /** Returns a strng representation of the shuttle object details
     *  @return string representation of the shuttle
     */
    public String toString()
    {
        return "\nJourney Code: " + journeyCode + "\n***Source World***" + sourceWorld.toString() + "\n***Destination World***" + destinationWorld.toString();
    }
}
