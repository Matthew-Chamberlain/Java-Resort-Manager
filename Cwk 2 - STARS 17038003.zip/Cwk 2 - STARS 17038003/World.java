import java.util.ArrayList;
/**
 * Used to store information about the worlds including the world number, the name of the world, the rating of the world, the capacity of the world and the collection of cards on the world.
 *
 * @author Matthew Chamberlain
 * @version 09/04/20
 */

public class World
{
    private int worldNumber;
    private String worldName;
    private int worldRating;
    private int capacity;
    
    private ArrayList<Card> cardCollection;
    
    /** Creates a world object and stores values given from in the function call in the fields 
     *  @param number represents the number of the world
     *  @param name represents the name of the world
     *  @param rating represents the rating of the world, this represents how high a card needs to be rated in order to travel to the world
     *  @param maxPeople represents the amount of people that can visit the world at one time
     *  card collection is an array list created to store the cards that are currently on that world
     */
    public World(int number, String name, int rating, int maxPeople)
    {
        worldNumber = number;
        worldName = name;
        worldRating = rating;
        capacity = maxPeople;
        cardCollection = new ArrayList<Card>();
    }
    
    /** Returns the world number
     * @return world number
     */    
    public int getNumber()
    {
        return worldNumber;
    }
    
    /** Returns the name of the world
     * @return world name
     */    
    public String getName()
    {
        return worldName;
    }
    
    /** Returns the rating of the world
     * @return world rating
     */    
    public int getRating()
    {
        return worldRating;
    }
    
    /** Returns the capacity of the world 
     * @return capacity
     */    
    public int getCapacity()
    {
        return capacity;
    }
    
    /** Adds a card to the card collection
     * @param card represents the card object to be added to the array list
     */    
    public void enter(Card card)
    {
        cardCollection.add(card);
    }
    
    /** Removes a card from the card collection
     *  @param card represnts the card object to be removed from the array list
     */    
    public void leave(Card card)
    {
        cardCollection.remove(card);
    }
    
    /** Returns false if the amount of cards in the arraylist is less than the capacity of the world and false otherwise
     *  @return false if not full and true if full
     */    
    public boolean isFull()
    {
        if(cardCollection.size() < capacity)
        {
            return false;
        }
        else
        {
            return true;
        }
    }
    
    /** Returns a string representation all the cards and their details that are in the array list, if the array list is empty a string is returned which states the world is empty
     *  @return a string containing all the cards on the world as well as their detials or a message stating the world is empty if the array list is empty
     */    
    public String listCards()
    {
        String list = "";
        if(cardCollection.size() > 0)
        {
            for(int i = 0; i < cardCollection.size(); i++)
            {
                Card temp = cardCollection.get(i);
                list += "\n" + temp.toString();
            }
            return list;
        }
        else
        {
            return "\nWorld Empty";
        }
    }
    
    /** Returns a true if a given id of a card matches with one of the id of the cards in the array list and false if there is no match
     *  @param ID represents the ID of the card to be checked
     *  @return true if card appears in the array list and false if the card is not in the list
     */    
    public boolean isOnWorld(int  ID)
    {
        for(int i = 0; i < cardCollection.size(); i++)
        {
            Card temp = cardCollection.get(i);
            if(temp.getID() == ID)
            {
                return true;
            }
        }
        return false;
    }
    
    /** Returns a string representation of all the details of the world including all the cards on the world and their details
     *  @return string containing details of the world and cards on the world
     */    
    public String toString()
    {
        return "\nWorld Number: " + worldNumber + "\nName: " + worldName + "\nRating: " + worldRating + "\nCapacity: " + capacity + "\n***Card Collection***" + listCards();
    }
}
