/** Used to store information about a card including the Id, the name of the owner, the rating, the credits and the loyalty points 
 * 
 * @author Matthew Chamberlain
 * @date 09/04/20
 */
public class Card
{
    private int cardID;
    private String name;
    private int rating;
    private int credits;
    private int points;
    
    /** Creates a card object and stores default values given from where the function was called into the fields.
     *  @param id represents the id of the card
     *  @param nme represents the name of the owner of the card
     *  @param luxaryRating reprsetnts the rating of the card which determines which worlds this card is allowed to visit.
     *  @param crdts represents the credits
     *  all cards start off with 0 loyalty points by default
     */
    public Card(int id, String nme, int luxaryRating, int crdts)
    {
        cardID = id;
        name = nme;
        rating = luxaryRating;
        credits = crdts;
        points = 0;
    }
    
    /** Returns the id of the card
     * @return card id
     */
    public int getID()
    {
        return cardID;
    }
    
    /** Returns the name of the card owner
     * @return card ownwers name
     */
    public String getName()
    {
        return name;
    }
    
    /** Returns the rating of the card
     * @return rating
     */
    public int getRating()
    {
        return rating;
    }
    
    /** Returns the number of credits the card has
     * @returns credits
     */
    public int getCredits()
    {
        return credits;
    }
    
    /** Returns the number of
     * @return loyalty points
     */
    public int getPoints()
    {
        return points;
    }
    
    /** adds a given amount to the number of credits, can be positive or negative, allows the use of same method to take away and add to credits
     *  @param amount represents the amount the that the number of credits will increase or decrease by.
     */
    public void changeCredits(int amount)
    {
        credits += amount;
    }
    
    /** adds a given amount to the number of loyalty points, can be positive or negative, allows the use of same method to take away and add to points
     *  @param represents the amount the that the number of points will increase or decrease by.
     */
    public void addPoints(int amount)
    {
        points += amount;
    }
    
    /** converts 4 loyalty points to 1 credit
     * 
     */
    public void pointsToCredits()
    {
        credits += points / 4;
        points -=  (points / 4) * 4; // this line ensures that leftover credits stay on the card, eg if the card has 6 points, 2 should remain
    }
    
     /** Returns true if the given id is equal to that of the card and false otherwise
     *  @param ID represents the id to be checked againts the cards id
     *  @return true if the given id matches the cards id and false otherwise
     */
    public boolean checkID(int ID)
    {
        if(ID == cardID)
        {
            return true;
        }
        else
        {
            return false;
        }
    }
    
     /** Returns a string representation of the cards information
     *  @return the information of the card as a string
     */
    public String toString()
    {
        return "ID: " + cardID + "  Name: " + name + "  Rating: " + rating + "   Credits: " + credits + "   Loyalty Points: " + points;
    }
}
