
/**
 * Runs the tester class .
 *
 * @author Matthew Chamberlain
 * @version 09/04/20
 */
public class RunTester
{
    /** Creates a MyTester object and calls the method to run the tests
     * 
     */
    public static void main(String[] args)
    {
        MyTester xx = new MyTester();
        xx.doTest1();
    }
}
