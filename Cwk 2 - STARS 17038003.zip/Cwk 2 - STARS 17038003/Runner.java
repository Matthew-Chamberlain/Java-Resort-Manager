
/**
 * This class runs the coursework 2 program.
 *
 * @author Matthew Chamberlain
 * @version 09/04/20
 */
public class Runner

{
    /** Main method used to run the program by creating a resort UI object and calling the runUI method
     * 
     */    
    public static void main(String[] args)
    {
        ResortUI xxx = new ResortUI();
        xxx.runUI();
    }
}
