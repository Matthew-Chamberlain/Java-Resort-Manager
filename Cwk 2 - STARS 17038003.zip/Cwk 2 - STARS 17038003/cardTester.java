
/**
 *  Used to test the methods of the card class by creating a few card objects.
 *
 * @author Matthew Chamberlain
 * @version 09/04/20
 */
public class cardTester
{   
    /** Makes a few card objects to test the methdos of the card class work correctly
     * 
     */
    public static void main(String[]args)
    {
        Card card1 = new Card(1000, "Matthew", 5, 10);
        Card card2 = new Card(2000, "Abbie", 3, 2);
        Card card3 = new Card(3000, "Jack", 7, 15);
        
        System.out.println(card1.getID());
        System.out.println(card2.getName());
        System.out.println(card3.getRating());
        System.out.println(card1.getCredits());
        System.out.println(card2.getPoints());
        
        card1.changeCredits(-3);
        
        card2.addPoints(5);
        System.out.println(card2.getPoints());
        card2.pointsToCredits();
        
        System.out.println(card3.checkID(3000));
        System.out.println(card3.checkID(2000));
        
        System.out.println(card1.toString());
        System.out.println(card2.toString());
        System.out.println(card3.toString());
    }
}
